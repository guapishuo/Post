create procedure myproc()
  begin
declare num int ;
set num = 1;
while num <= 100000 do
insert into lagou_p3 values(num,2,3);set num=num+1;
end while;
end;

